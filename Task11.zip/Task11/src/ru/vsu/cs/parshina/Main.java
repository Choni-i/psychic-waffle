package ru.vsu.cs.parshina;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        List<Character> result = readListFromFile("input_01.txt");
        //List<Character> result = readListFromFile("input_02.txt");
        Output(result);

    }




        public static List<Character> readListFromFile(String filename) throws IOException {
            //Scanner scanner = new Scanner(new File(filename));
            /*boolean comment = false; // показывает, что /* встретилось
            boolean probel = false;
            int k = 0;
            Scanner s = new Scanner(filename).useDelimiter("\\n");
                while(s.hasNext()) {
                    String content = s.next();
                }*/


            ArrayList<String> list = new ArrayList<String>();
            Scanner scanner = new Scanner(new File(filename)); // считали
            while(scanner.hasNextLine()) {
                list.add(scanner.nextLine());
            }
            scanner.close();
            //list.toArray(new String[0]);
            String[] content = list.toArray(new String[0]);// сконвертировали в массив стринг
             return Solution(content);
        }


        public static boolean ProbelOrNo(char a) { // чтобы понять что было до/* и после */
            return ((a != ' ') && (a != '}') && (a != ';') && (a != '\\') && (a != '/') && (a != '*') && (a != ',')) && (a != '_') && (a != '{');
        }


        public static List<Character> Solution(String[] arr){
            boolean comment = false; // показывает, что /* встретилось
            boolean probel = false;
            int k = 0;

            List<Character> result = new ArrayList<>();
            for (String s : arr) {

                char[] parts = s.toCharArray();

                //String[] parts = line.split("");
                if (parts.length == 1) { // если длина 1, то просто печатем, но смотрим чтобы раньше не встретилось /*
                    if (comment) {
                        continue;
                    }
                    result.add(parts[0]);
                    result.add('\n');
                    continue;
                }
                if (parts.length == 2) { // если длина 2 перебираем все варинаты(так потому что в самом цикле сдвиг на i+2 и он просто не достает до них
                    if ((parts[0] == '/') && (parts[1] == '*')) {
                        comment = true;
                        k++;
                    } else if ((parts[0] == '/') && (parts[1] == '/')) {
                        continue;
                    } else if ((comment) && (parts[0] == '*') && (parts[1] == '/')) {
                        comment = false;
                        k = 0;

                    } else {
                        if (comment) {
                            continue;
                        }
                        result.add(parts[0]);
                        result.add(parts[1]);
                        result.add('\n');
                    }
                    continue;
                }
                if (parts.length == 3) { // если длина 3 перебираем все варинаты(так потому что в самом цикле сдвиг на i+2 и он просто не достает до них
                    if (parts[0] == '/') {
                        if (parts[1] == '/') {
                            result.add('\n');
                            continue;
                        }
                        if (parts[1] == '*') {
                            comment = true;
                            k++;
                            continue;
                        }
                    } else if ((comment) && ((parts[0] == '*') && (parts[1] == '/'))) {
                        comment = false;
                        probel = false;
                        result.add(parts[2]);
                        if (k==0) {result.add('\n');}
                        k = 0;
                        continue;
                    } else if ((comment) && ((parts[1] == '*') && (parts[2] == '/'))) {
                        comment = false;
                        probel = false;
                        if (k==0) {result.add('\n');}
                        k = 0;
                        continue;
                    } else if (parts[1] == '/') {
                        if (parts[2] == '/') {
                            result.add(parts[0]);
                            result.add('\n');
                            continue;
                        }
                        if (parts[2] == '*') {
                            result.add(parts[0]);
                            result.add('\n');
                            comment = true;
                            k++;
                            continue;
                        }
                    } else {
                        if (comment) {
                            continue;
                        }
                    }
                }
                for (int i = 0; i < parts.length - 2; i++) {
                    if ((comment) && !((parts[i] == '*') && (parts[i + 1] == '/'))) { // пытаемся найти */, если было /*
                        if (i + 2 == parts.length - 1) {
                            if ((parts[i + 1] == '*') && (parts[i + 2] == '/')) {
                                comment = false;
                                probel = false;
                                if (k == 0) {
                                    result.add('\n');
                                }
                            } else {
                                k++;
                            }
                        }
                    } else {
                        if ((parts[i] == '/') && (parts[i + 1] == '/')) {
                            break;
                        }
                        if ((parts[i] == '/') && (parts[i + 1] == '*')) {
                            comment = true;
                            if (i != 0) {
                                if (ProbelOrNo(parts[i - 1])) {
                                    probel = true;
                                }
                            }
                            continue;
                        }
                        if ((parts[i] == '*') && (parts[i + 1] == '/')) {
                            comment = false;
                            if (probel && ProbelOrNo(parts[i + 2])) {
                                result.add(' ');
                                probel = false;
                            }
                            if (i + 2 == parts.length - 1) {
                                result.add(parts[i + 2]);
                                result.add('\n');
                            }
                            k = 0;
                            continue;
                        }
                        if (i + 2 == parts.length - 1) { // опять та же штука, он не достает до конца строки, так что своими ручками всё перебрала
                            if ((parts[i] == '/')) {
                                if (!(parts[i + 1] == '/')) {
                                    result.add(parts[i + 1]);
                                    result.add(parts[i + 2]);
                                    result.add('\n');
                                }
                            } else if (parts[i + 1] == '/') {
                                result.add(parts[i]);
                                if (!(parts[i + 2] == '/')) {
                                    result.add(parts[i + 2]);
                                }
                                result.add('\n');

                            } else {
                                result.add(parts[i]);
                                result.add(parts[i + 1]);
                                result.add(parts[i + 2]);
                                result.add('\n');
                            }
                        } else if (i == 0) {
                            result.add(parts[0]);
                        } else if (!(parts[i] == '/') && !(parts[i] == '\\') && !(parts[i] == '*')) {
                            result.add(parts[i]);
                        }
                    }
                }

            }
            return result;
        }

        public static void Output(List<Character> list){ // печатаем в консоль
            for (char a : list) {
                System.out.print(a);
            }
        }
}




